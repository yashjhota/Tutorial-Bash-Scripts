#!/bin/bash

a="yash"
b="yashh"

if test "$a" = "$b"
then echo "A is equalt to bo"
else echo "Not equal"
fi