#!/bin/bash
read -p "Enter USername : " username
echo "Helllo $username"
echo ""