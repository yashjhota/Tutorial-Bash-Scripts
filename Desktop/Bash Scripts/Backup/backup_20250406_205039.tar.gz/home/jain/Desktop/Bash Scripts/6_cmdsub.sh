#! /bin/bash

echo "Command subsution Tutorial"
  
current_directory=$(pwd) 

echo "Your working in: "$current_directory  

echo "Making a new directory "

