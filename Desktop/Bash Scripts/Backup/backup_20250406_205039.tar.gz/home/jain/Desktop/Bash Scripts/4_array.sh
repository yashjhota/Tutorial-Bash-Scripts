#!/bin/bash

namelist=(yash yasha yashika)

# echo ${namelist[2]}
# echo  "All Array Elements : " ${namelist[*]}
# echo  ${namelist[@]}

# echo $namelist
